# backend/settings/development.py
from .base import *

DEBUG = env.bool('DEBUG', default=True)

DATABASES = {
    'default': env.db('DEV_DB_URL')
}


ALLOWED_HOSTS = ['editorial.clous.app', 'ec2-13-39-125-67.eu-west-3.compute.amazonaws.com', 'localhost', '13.39.125.67', '127.0.0.1',]

# Redirige todas las solicitudes a HTTPS
SECURE_SSL_REDIRECT = False

CORS_ORIGIN_WHITELIST = [
    'http://localhost:3000',
    'http://localhost:3001',
    'https://www.clous.app',
]

CSRF_TRUSTED_ORIGINS = [
    'http://localhost:3000',
    'http://localhost:3001',
    'https://www.clous.app',
]
CORS_ALLOW_CREDENTIALS = True

if 'debug_toolbar' in INSTALLED_APPS:
    MIDDLEWARE += ['debug_toolbar.middleware.DebugToolbarMiddleware']
    INTERNAL_IPS = ['127.0.0.1']
