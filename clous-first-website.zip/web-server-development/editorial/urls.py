from django.urls import path
from .views import NewsListView, NewsDetailView, BlogListView, BlogDetailView

urlpatterns = [
    path('news/list', NewsListView.as_view(), name='news-list'),
    path('news/details/<slug>', NewsDetailView.as_view(), name='news-detail'),

    # Repite para otros modelos (Blog, HRTalks, Research, Guide, HelpCenter)...

    path('blogs/list', BlogListView.as_view(), name='blog-list'),
    path('blogs/details/<slug>', BlogDetailView.as_view(), name='blog-detail'),
]
