from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.generics import ListAPIView, RetrieveAPIView

from users.models import UserAccount
from users.serializers import UserProfileSerializer
from .models import News, Blog, HRTalks, Research, Guide, HelpCenter
from .serializers import (
    ContentSectionSerializer, NewsSerializer, BlogSerializer, HRTalksSerializer,
    ResearchSerializer, GuideSerializer, HelpCenterSerializer
)
from rest_framework.permissions import IsAuthenticated
from rest_framework import permissions


# Vista para obtener una lista de todas las noticias
class NewsListView(ListAPIView):
    permission_classes = (permissions.AllowAny,)

    def get(self, request, *args, **kwargs):
        news_queryset = News.objects.filter(status=News.Status.PUBLISHED)
        serialized_news = NewsSerializer(news_queryset, many=True).data

        # Ahora, serializamos manualmente el perfil del autor para cada noticia
        for entry in serialized_news:
            author_id = entry['author']
            try:
                author_profile = UserAccount.objects.get(user_id=author_id)
                entry['author_profile'] = UserProfileSerializer(author_profile).data
            except UserAccount.DoesNotExist:
                entry['author_profile'] = None

        return Response(serialized_news, status=status.HTTP_200_OK)

# Vista para obtener detalles de una noticia específica
class NewsDetailView(RetrieveAPIView):
    lookup_field = 'slug'
    permission_classes = (permissions.AllowAny,)
    queryset = News.objects.filter(status=News.Status.PUBLISHED)
    serializer_class = NewsSerializer

    def post(self, request, *args, **kwargs):
        news_instance = self.get_object()

        if 'vote' in request.data:
            vote_choice = request.data['vote']

            # Check if the user has already voted
            user_has_voted = request.session.get(f'voted_{news_instance.id}', False)

            if not user_has_voted:
                if vote_choice == 'yes':
                    news_instance.yes_count += 1
                elif vote_choice == 'no':
                    news_instance.no_count += 1

                news_instance.save()

                # Mark the user as voted in session
                request.session[f'voted_{news_instance.id}'] = True
                request.session.save()
            else:
                return Response({"error": "User has already voted for this news."}, status=status.HTTP_400_BAD_REQUEST)
        # Return a response with updated news details
        serialized_news = NewsSerializer(news_instance).data
        return Response(serialized_news, status=status.HTTP_200_OK)


    def get(self, request, *args, **kwargs):
        # Obtén la instancia de News asociada a la vista
        news_instance = self.get_object()

        # Obtén la lista de noticias vistas en la sesión actual
        viewed_news = request.session.get('viewed_news', [])

        # Incrementa el conteo de vistas solo si la noticia no ha sido vista en esta sesión
        if news_instance.id not in viewed_news:
            news_instance.view_count += 1
            news_instance.save()

            # Marca la noticia como vista en esta sesión
            viewed_news.append(news_instance.id)
            request.session['viewed_news'] = viewed_news

        # Resto del código para serializar y devolver la respuesta
        serialized_news = NewsSerializer(news_instance).data

        # Serializa manualmente el perfil del autor
        author_id = serialized_news['author']
        try:
            author_profile = UserAccount.objects.get(user_id=author_id)
            serialized_news['author_profile'] = UserProfileSerializer(author_profile).data
            serialized_news['first_name'] = author_profile.user.first_name
            serialized_news['last_name'] = author_profile.user.last_name
        except UserAccount.DoesNotExist:
            serialized_news['author_profile'] = None
            serialized_news['first_name'] = None
            serialized_news['last_name'] = None

        # Accede a las ContentSection asociadas a la instancia de News
        content_sections = news_instance.content_sections.all()
        serialized_content_sections = ContentSectionSerializer(content_sections, many=True).data

        # Agrega las ContentSection serializadas a la respuesta
        serialized_news['content_sections'] = serialized_content_sections

        return Response(serialized_news, status=status.HTTP_200_OK)
# Repite el proceso para otros modelos (Blog, HRTalks, Research, Guide, HelpCenter)...

# Ejemplo para la vista de lista de blogs
# views.py

# Vista para obtener una lista de todos los blogs
class BlogListView(ListAPIView):
    queryset = Blog.objects.filter(status=Blog.Status.PUBLISHED)
    serializer_class = BlogSerializer

# Vista para obtener detalles de un blog específico
class BlogDetailView(RetrieveAPIView):
    lookup_field = 'slug'
    queryset = Blog.objects.filter(status=Blog.Status.PUBLISHED)
    serializer_class = BlogSerializer


# Puedes repetir este patrón para los otros modelos (HRTalks, Research, Guide, HelpCenter)...

