""" models.py """
import uuid
from users.models import User
from django.db import models
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from ckeditor.fields import RichTextField
from django.utils.translation import gettext_lazy as _
from django.contrib.contenttypes.fields import GenericRelation



class ContentSection(models.Model):
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.PositiveIntegerField()
    content_object = GenericForeignKey('content_type', 'object_id')

    heading = models.CharField(max_length=200)
    content = RichTextField()
    image = models.URLField()

    def __str__(self):
        return f"{self.heading} - {self.content_object}"

class ContentBase(models.Model):
    class Status(models.TextChoices):
        DRAFT = 'DR', _('Draft')
        PUBLISHED = 'PU', _('Published')

    author = models.ForeignKey(User, on_delete=models.CASCADE)
    cover = models.URLField()
    title = models.CharField(max_length=200)
    introduction = RichTextField()
    conclusion = RichTextField()
    slug =  models.SlugField(max_length=255, unique=True, default=uuid.uuid4)
    view_count = models.PositiveIntegerField(default=0)
    yes_count = models.PositiveIntegerField(default=0)
    no_count = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    reading_time = models.PositiveIntegerField(default=5, help_text="Estimated reading time in minutes")
    content_sections = GenericRelation(ContentSection)

    # Tus campos existentes...
    status = models.CharField(
        max_length=2,
        choices=Status.choices,
        default=Status.DRAFT,
    )

    class Meta:
        abstract = True
        verbose_name = "Content Base"
        verbose_name_plural = "Contents Base"

    def __str__(self):
        return self.title
    
    
class News(ContentBase):
    # Aquí puedes agregar campos específicos para News si los hay
    class Meta:
        verbose_name = "News"
        verbose_name_plural = "News"

    def __str__(self):
        return f"News: {self.title}"


class HRTalks(ContentBase):
    # Campos específicos para HR Talks

    class Meta:
        verbose_name = "HRTalks"
        verbose_name_plural = "HRTalks"

    def __str__(self):
        return f"HR Talks: {self.title}"


CATEGORY_CHOICES = [
    ('cat1', 'Tips & Tricks'),
    ('cat2', 'How-to'),
    ('cat3', 'Technology'),
    ('cat4', 'Talent'),
]


class Blog(ContentBase):
    category = models.CharField(
        max_length=100,
        choices=CATEGORY_CHOICES,
        default='cat1'
    )

    class Meta:
        verbose_name = "Blog"
        verbose_name_plural = "Blog"

    def __str__(self):
        return f"Blog: {self.title}"


class Research(ContentBase):
    # Campos específicos para Research
    class Meta:
        verbose_name = "Research"
        verbose_name_plural = "Research"

    def __str__(self):
        return f"Research: {self.title}"


class Guide(ContentBase):
    video = models.URLField(blank=True, null=True)

    class Meta:
        verbose_name = "Guide"
        verbose_name_plural = "Guide"

    def __str__(self):
        return f"Guide: {self.title}"


class HelpCenter(ContentBase):
    class Meta:
        verbose_name = "HelpCenter"
        verbose_name_plural = "HelpCenter"

    def __str__(self):
        return f"Help Center: {self.title}"

