""" serializers.py """
from rest_framework import serializers

from users.serializers import UserProfileSerializer
from .models import News, Blog, HRTalks, Research, Guide, HelpCenter, ContentSection, ContentBase


class ContentBaseSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = ContentBase
        fields = ['author', 'cover', 'title', 'introduction', 'conclusion', 'view_count', 'yes_count', 'no_count', 'status', 'slug', 'reading_time']


class ContentSectionSerializer(serializers.ModelSerializer):
    class Meta:
        model = ContentSection
        fields = ['heading', 'content', 'image', 'content_type', 'object_id']


class NewsSerializer(serializers.ModelSerializer):
    content_sections = ContentSectionSerializer(many=True, read_only=True)

    class Meta(ContentBaseSerializer.Meta):
        model = News
        fields = ContentBaseSerializer.Meta.fields + ['content_sections']


class BlogSerializer(ContentBaseSerializer):
    content_sections = ContentSectionSerializer(many=True, read_only=True)

    class Meta(ContentBaseSerializer.Meta):
        model = Blog
        fields = ContentBaseSerializer.Meta.fields + ['category'] + ['content_sections']


class HRTalksSerializer(ContentBaseSerializer):
    content_sections = ContentSectionSerializer(many=True, read_only=True)

    class Meta(ContentBaseSerializer.Meta):
        model = HRTalks
        fields = ContentBaseSerializer.Meta.fields + ['content_sections']


class ResearchSerializer(ContentBaseSerializer):
    content_sections = ContentSectionSerializer(many=True, read_only=True)

    class Meta(ContentBaseSerializer.Meta):
        model = Research
        fields = ContentBaseSerializer.Meta.fields + ['content_sections']


class GuideSerializer(ContentBaseSerializer):
    content_sections = ContentSectionSerializer(many=True, read_only=True)

    class Meta(ContentBaseSerializer.Meta):
        model = Guide
        fields = ContentBaseSerializer.Meta.fields + ['video'] + ['content_sections']


class HelpCenterSerializer(ContentBaseSerializer):
    content_sections = ContentSectionSerializer(many=True, read_only=True)

    class Meta(ContentBaseSerializer.Meta):
        model = HelpCenter
        fields = ContentBaseSerializer.Meta.fields + ['content_sections']
